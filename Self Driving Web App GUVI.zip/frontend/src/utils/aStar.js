export function findPathAStar(startPt, endPt, grid){
  const MAP_SIZE = grid.length
  const inBounds = (x,y)=> x>=0 && y>=0 && x<MAP_SIZE && y<MAP_SIZE
  const key = (p)=> `${p.x},${p.y}`
  function neighbors(p){
    const dirs = [[0,1],[0,-1],[1,0],[-1,0]]
    const out=[]
    for(const d of dirs){
      const nx=p.x+d[0], ny=p.y+d[1]
      if(inBounds(nx,ny) && grid[nx][ny]===0) out.push({x:nx,y:ny})
    }
    return out
  }
  function heuristic(a,b){ return Math.abs(a.x-b.x)+Math.abs(a.y-b.y) }

  class MinHeap {
    constructor(cmp){ this.cmp=cmp; this.data=[] }
    empty(){ return this.data.length===0 }
    push(v){ this.data.push(v); this._siftUp(this.data.length-1) }
    pop(){ if(this.empty()) return null; const top=this.data[0]; const last=this.data.pop(); if(!this.empty()){ this.data[0]=last; this._siftDown(0) } return top }
    _siftUp(i){ while(i>0){ const p=(i-1)>>1; if(this.cmp(this.data[i],this.data[p])<0){ [this.data[i],this.data[p]]=[this.data[p],this.data[i]]; i=p } else break } }
    _siftDown(i){ const n=this.data.length; while(true){ let l=2*i+1, r=l+1, smallest=i; if(l<n && this.cmp(this.data[l],this.data[smallest])<0) smallest=l; if(r<n && this.cmp(this.data[r],this.data[smallest])<0) smallest=r; if(smallest===i) break; [this.data[i],this.data[smallest]]=[this.data[smallest],this.data[i]]; i=smallest } }
  }

  const openHeap = new MinHeap((a,b)=> a.f - b.f || a.h - b.h)
  const openSet = new Map()
  const cameFrom = new Map()
  const gScore = new Map()

  gScore.set(key(startPt),0)
  openHeap.push({pos:startPt, f:heuristic(startPt,endPt), h:heuristic(startPt,endPt)})
  openSet.set(key(startPt), true)

  while(!openHeap.empty()){
    const current = openHeap.pop()
    const currKey = key(current.pos)
    openSet.delete(currKey)

    if(current.pos.x===endPt.x && current.pos.y===endPt.y){
      const path=[]
      let curK = currKey
      while(curK){
        const [cx,cy] = curK.split(',').map(Number)
        path.unshift({x:cx,y:cy})
        curK = cameFrom.get(curK)
      }
      return path
    }

    for(const n of neighbors(current.pos)){
      const ng = (gScore.get(currKey) || 0) + 1
      const nk = key(n)
      if(ng < (gScore.get(nk) ?? Infinity)){
        cameFrom.set(nk, currKey)
        gScore.set(nk, ng)
        const h = heuristic(n, endPt)
        const f = ng + h
        if(!openSet.has(nk)){
          openSet.set(nk, true)
          openHeap.push({pos:n, f, h})
        }
      }
    }
  }
  return []
}
