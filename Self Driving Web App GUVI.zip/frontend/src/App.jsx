import React, { useState, useEffect, useRef } from 'react'
import { findPathAStar } from './utils/aStar'
import axios from 'axios'

const MAP_SIZE = 10
const defaultObstacleMap = [
  [0,0,0,0,0,0,0,0,0,0],
  [0,1,1,1,1,1,1,1,1,0],
  [0,0,0,0,0,0,0,0,1,0],
  [0,0,0,0,0,0,0,0,1,0],
  [0,1,1,1,1,1,0,0,1,0],
  [0,1,0,0,0,1,0,0,1,0],
  [0,1,0,0,0,1,0,0,1,0],
  [0,1,0,0,0,1,0,0,0,0],
  [0,1,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0],
]

function apiClient(token){
  const instance = axios.create({ baseURL: 'http://localhost:4000' })
  if(token) instance.defaults.headers.common['Authorization'] = 'Bearer ' + token
  return instance
}

export default function App(){
  const [token,setToken] = useState(localStorage.getItem('token')||'')
  const [role,setRole] = useState(localStorage.getItem('role')||'')
  const [username,setUsername] = useState('')
  const [password,setPassword] = useState('')

  const [obstacles,setObstacles] = useState(defaultObstacleMap)
  const [start,setStart] = useState({x:0,y:0})
  const [end,setEnd] = useState({x:MAP_SIZE-1,y:MAP_SIZE-1})
  const [mode,setMode] = useState('toggle')
  const [path,setPath] = useState([])
  const [maxSpeed,setMaxSpeed] = useState(1.0)
  const [animating,setAnimating] = useState(false)
  const [carPos,setCarPos] = useState(start)
  const [history,setHistory] = useState([])
  const animRef = useRef(null)

  useEffect(()=>{ setCarPos(start) },[start])

  function cloneGrid(g){ return g.map(r=>r.slice()) }

  function toggleObstacle(x,y){
    if(mode === 'toggle'){
      const g = cloneGrid(obstacles)
      g[x][y] = g[x][y] === 1 ? 0 : 1
      setObstacles(g)
    } else if(mode === 'setStart'){ setStart({x,y}); setMode('toggle') }
    else if(mode === 'setEnd'){ setEnd({x,y}); setMode('toggle') }
  }

  function runPathfinding(){
    if(obstacles[start.x][start.y]===1 || obstacles[end.x][end.y]===1){ alert('Start or End on obstacle'); return }
    const p = findPathAStar(start,end,obstacles)
    setPath(p)
    setCarPos(start)
  }

  function startDrive(save=true){
    if(!path || path.length===0){ alert('No path found. Run pathfinding first.'); return }
    if(animating) return
    setAnimating(true)
    let i=0
    const interval = Math.max(50, Math.floor(1000 / maxSpeed))
    animRef.current = setInterval(()=>{
      i++
      if(i>=path.length){ clearInterval(animRef.current); setAnimating(false); setCarPos(end); 
        if(save) saveRun(); return }
      setCarPos(path[i])
    }, interval)
  }

  function stopDrive(){ if(animRef.current) clearInterval(animRef.current); setAnimating(false) }

  async function saveRun(){
    if(!token) return
    try{
      const client = apiClient(token)
      await client.post('/maps/save', { map: obstacles, start, end, role })
    }catch(err){ console.error('save failed', err) }
  }

  async function loadHistory(){
    if(!token){ alert('Login to view history'); return }
    try{
      const client = apiClient(token)
      const res = await client.get('/maps/history')
      setHistory(res.data.maps || [])
    }catch(err){ alert('Failed to load history') }
  }

  async function loadMap(id){
    if(!token) return
    try{
      const client = apiClient(token)
      const res = await client.get(`/maps/${id}`)
      if(res.data && res.data.map) setObstacles(res.data.map)
    }catch(err){ alert('Failed to load map') }
  }

  async function handleLogin(e){
    e.preventDefault()
    try{
      const res = await axios.post('http://localhost:4000/auth/login', { username, password })
      if(res.data && res.data.token){
        setToken(res.data.token)
        setRole(res.data.role)
        localStorage.setItem('token', res.data.token)
        localStorage.setItem('role', res.data.role)
        alert('Login successful as ' + res.data.role)
      }
    }catch(err){ alert('Login failed') }
  }

  function logout(){
    setToken(''); setRole(''); localStorage.removeItem('token'); localStorage.removeItem('role')
  }

  return (
    <div className="container">
      <h1>Self-Driving Web App</h1>

      {!token ? (
        <form onSubmit={handleLogin} style={{marginTop:12}}>
          <h3>Login</h3>
          <div><input placeholder="username" value={username} onChange={e=>setUsername(e.target.value)} /></div>
          <div style={{marginTop:8}}><input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /></div>
          <div style={{marginTop:8}}><button type="submit">Login</button></div>
          <p style={{marginTop:8}}>Seeded users: admin/admin123, driver/driver123, tech/tech123</p>
        </form>
      ) : (
        <>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div>Signed in as <strong>{role}</strong></div>
            <div><button onClick={logout}>Logout</button></div>
          </div>

          <div style={{display:'flex',gap:24,marginTop:12}}>
            <div>
              <div className="grid">
                {Array.from({length:MAP_SIZE}).map((_,x)=>(
                  Array.from({length:MAP_SIZE}).map((__,y)=>{
                    const isObstacle = obstacles[x][y]===1
                    const isStart = start.x===x && start.y===y
                    const isEnd = end.x===x && end.y===y
                    const inPath = path.some(p=>p.x===x && p.y===y)
                    const isCar = carPos.x===x && carPos.y===y
                    const style = { width:32,height:32,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',
                      border:'1px solid #ddd', background: isCar? '#60a5fa' : isStart? '#34d399' : isEnd? '#fb7185' : isObstacle? '#111827' : inPath? '#fde68a' : '#fff'
                    }
                    return <div key={`${x}-${y}`} style={style} onClick={()=>toggleObstacle(x,y)} title={`(${x},${y})`} />
                  })
                ))}
              </div>
            </div>

            <div style={{minWidth:300}}>
              <div style={{marginBottom:12}}>
                <label>Mode</label>
                <div style={{display:'flex',gap:8,marginTop:6}}>
                  <button onClick={()=>setMode('toggle')}>Toggle Obstacles</button>
                  <button onClick={()=>setMode('setStart')}>Set Start</button>
                  <button onClick={()=>setMode('setEnd')}>Set End</button>
                </div>
              </div>

              <div style={{display:'flex',gap:8,marginBottom:12}}>
                <button onClick={runPathfinding}>Find Path (A*)</button>
                <button onClick={()=>{ runPathfinding(); startDrive(); }}>Start Drive & Save Run</button>
                <button onClick={stopDrive}>Stop</button>
              </div>

              <div style={{marginBottom:12}}>
                <label>Max Speed</label>
                <input type='number' step='0.1' value={maxSpeed} onChange={(e)=>setMaxSpeed(Number(e.target.value)||1)} style={{width:'100%',padding:8,marginTop:6}} />
              </div>

              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>setObstacles(defaultObstacleMap.map(r=>r.slice()))}>Reset Map</button>
                <button onClick={()=>setObstacles(Array.from({length:MAP_SIZE},()=>Array.from({length:MAP_SIZE},()=>0)))}>Clear Map</button>
                <button onClick={loadHistory}>Load History</button>
              </div>

              <div style={{marginTop:12}}>
                <p>Start: ({start.x},{start.y})</p>
                <p>End: ({end.x},{end.y})</p>
                <p>Path length: {path.length ? path.length-1 : 0}</p>
                <p>Car position: ({carPos.x},{carPos.y})</p>
              </div>

              <div style={{marginTop:12}}>
                <h4>Map History</h4>
                {history.length===0 && <p>No history loaded. Click 'Load History'.</p>}
                <ul>
                  {history.map(h=>(
                    <li key={h.id} style={{marginBottom:8, border:'1px solid #eee', padding:8}}>
                      <div>Id: {h.id} — savedAt: {new Date(h.savedAt).toLocaleString()} — by: {h.role}</div>
                      <div style={{marginTop:6}}>
                        <button onClick={()=>loadMap(h.id)}>Load this map</button>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
