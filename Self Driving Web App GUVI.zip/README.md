# Self-Driving Web App (React + Express + SQLite)

## What's included
- `frontend/` — Vite + React app. Contains the UI, A* pathfinding, animations, login, and history UI.
- `server/` — Express backend with JWT authentication and SQLite database (maps & users).

## Quick start (locally)
1. Install Node.js (v16+ recommended) and npm.
2. From project root, install dependencies:
   - `npm run install:all`
3. Start both frontend and backend:
   - `npm start`

Frontend: http://localhost:5173  
Backend API: http://localhost:4000

Default seeded users:
- admin / admin123
- driver / driver123
- tech / tech123
