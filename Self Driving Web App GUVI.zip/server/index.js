const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const sqlite3 = require('sqlite3').verbose()
const path = require('path')
const fs = require('fs')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

const DB_FILE = path.join(__dirname, 'data', 'app.db')
if(!fs.existsSync(path.dirname(DB_FILE))) fs.mkdirSync(path.dirname(DB_FILE), { recursive: true })

const db = new sqlite3.Database(DB_FILE)

// Initialize tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT
  )`)
  db.run(`CREATE TABLE IF NOT EXISTS maps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    map_json TEXT,
    start_x INTEGER, start_y INTEGER,
    end_x INTEGER, end_y INTEGER,
    role TEXT,
    savedAt TEXT
  )`)

  // Seed users if not exists
  const users = [
    { username: 'admin', password: 'admin123', role: 'ADMIN' },
    { username: 'driver', password: 'driver123', role: 'DRIVER' },
    { username: 'tech', password: 'tech123', role: 'TECHNICIAN' },
  ]
  users.forEach(u=>{
    db.get('SELECT id FROM users WHERE username = ?', [u.username], (err,row)=>{
      if(err) return console.error(err)
      if(!row){
        const hash = bcrypt.hashSync(u.password, 8)
        db.run('INSERT INTO users (username,password,role) VALUES (?,?,?)', [u.username, hash, u.role])
      }
    })
  })
})

const app = express()
app.use(cors())
app.use(bodyParser.json({limit:'2mb'}))

const SECRET = 'replace_this_with_a_real_secret_in_prod'

function authenticateToken(req,res,next){
  const auth = req.headers['authorization']
  if(!auth) return res.status(401).json({error:'missing token'})
  const parts = auth.split(' ')
  if(parts.length !== 2) return res.status(401).json({error:'bad token'})
  const token = parts[1]
  jwt.verify(token, SECRET, (err, user) => {
    if(err) return res.status(403).json({error:'invalid token'})
    req.user = user
    next()
  })
}

app.post('/auth/login', (req,res)=>{
  const { username, password } = req.body
  if(!username || !password) return res.status(400).json({error:'username & password required'})
  db.get('SELECT * FROM users WHERE username = ?', [username], (err,row)=>{
    if(err) return res.status(500).json({error: 'db error'})
    if(!row) return res.status(401).json({error:'invalid credentials'})
    if(!bcrypt.compareSync(password, row.password)) return res.status(401).json({error:'invalid credentials'})
    const token = jwt.sign({ id: row.id, username: row.username, role: row.role }, SECRET, { expiresIn: '8h' })
    res.json({ token, role: row.role })
  })
})

app.post('/maps/save', authenticateToken, (req,res)=>{
  const { map, start, end } = req.body
  if(!map) return res.status(400).json({error:'map required'})
  const stmt = db.prepare('INSERT INTO maps (map_json,start_x,start_y,end_x,end_y,role,savedAt) VALUES (?,?,?,?,?,?,?)')
  stmt.run(JSON.stringify(map), start?.x||0, start?.y||0, end?.x||0, end?.y||0, req.user.role, new Date().toISOString(), function(err){
    if(err) return res.status(500).json({error:'db error'})
    res.json({ ok: true, id: this.lastID })
  })
})

app.get('/maps/latest', authenticateToken, (req,res)=>{
  db.get('SELECT * FROM maps ORDER BY id DESC LIMIT 1', [], (err,row)=>{
    if(err) return res.status(500).json({error:'db error'})
    if(!row) return res.json({})
    res.json({
      id: row.id,
      map: JSON.parse(row.map_json),
      start: { x: row.start_x, y: row.start_y },
      end: { x: row.end_x, y: row.end_y },
      role: row.role,
      savedAt: row.savedAt
    })
  })
})

app.get('/maps/history', authenticateToken, (req,res)=>{
  db.all('SELECT id, savedAt, role FROM maps ORDER BY id DESC LIMIT 50', [], (err,rows)=>{
    if(err) return res.status(500).json({error:'db error'})
    res.json({ maps: rows })
  })
})

app.get('/maps/:id', authenticateToken, (req,res)=>{
  const id = Number(req.params.id)
  db.get('SELECT * FROM maps WHERE id = ?', [id], (err,row)=>{
    if(err) return res.status(500).json({error:'db error'})
    if(!row) return res.status(404).json({error:'not found'})
    res.json({
      id: row.id,
      map: JSON.parse(row.map_json),
      start: { x: row.start_x, y: row.start_y },
      end: { x: row.end_x, y: row.end_y },
      role: row.role,
      savedAt: row.savedAt
    })
  })
})

const PORT = process.env.PORT || 4000
app.listen(PORT, ()=> console.log('Server listening on', PORT))
